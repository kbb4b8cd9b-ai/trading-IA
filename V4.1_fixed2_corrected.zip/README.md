# Trading AI Paper Automatizzato
Mantiene la UI mobile della demo e aggiunge un backend FastAPI con 10 agenti, consenso, Risk Guardian, posizioni, P/L, SL/TP e ciclo automatico ogni 5 secondi. Capitale virtuale iniziale 50 €. Il mercato è un simulatore random-walk: non usa quotazioni reali e non invia ordini a broker.


## Fix V4.1
La rotta `/` serve direttamente `index.html`, quindi aprendo la porta del Codespace non compare più `{"detail":"Not Found"}`.

## Fix V4.1_fixed2 corrected
La dashboard usa sempre l’origine del backend del Codespace, non mostra falsi errori dopo un singolo timeout e riprova automaticamente. Aggiunta anche `/health`. Il progetto resta esclusivamente PAPER: nessun ordine reale e nessuna chiave broker.
