from __future__ import annotations
import asyncio, random
from datetime import datetime, timezone
from typing import Literal
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="Trading AI Paper Engine", version="1.0.0")
INITIAL_BALANCE=50.0
SYMBOLS=["AAPL","MSFT","NVDA","TSLA","AMZN"]
AGENTS=["Trend Hunter","Momentum AI","Mean Reversion","Volatility Scout","Breakout AI","Risk Guardian","Macro Pulse","Pattern Vision","Portfolio Optimizer","Consensus Agent"]
state={"running":False,"balance":INITIAL_BALANCE,"equity":INITIAL_BALANCE,"realized_pnl":0.0,"unrealized_pnl":0.0,"trades":0,"prices":{s:100+random.random()*100 for s in SYMBOLS},"positions":{},"history":[],"agents":[],"curve":[INITIAL_BALANCE],"last_cycle":None,"cycle":0}

class RunRequest(BaseModel): enabled: bool=True

def now(): return datetime.now(timezone.utc).isoformat()

def market_step():
    for s in SYMBOLS:
        state["prices"][s]=max(1.0,state["prices"][s]*(1+random.gauss(0,0.004)))

def signal(agent,symbol):
    if agent=="Risk Guardian": return "HOLD",50
    bias={"Trend Hunter":.25,"Momentum AI":.35,"Mean Reversion":-.15,"Volatility Scout":.05,"Breakout AI":.2,"Macro Pulse":0,"Pattern Vision":.1,"Portfolio Optimizer":0,"Consensus Agent":.15}.get(agent,0)
    score=max(0,min(100,60+(random.uniform(-1,1)+bias)*25))
    return ("BUY",round(score)) if score>=67 else ("SELL",round(score)) if score<=40 else ("HOLD",round(score))

def update_positions():
    for symbol,p in list(state["positions"].items()):
        price=state["prices"][symbol]
        pnl=(price-p["entry_price"])*p["quantity"] if p["side"]=="LONG" else (p["entry_price"]-price)*p["quantity"]
        p["unrealized_pnl"]=pnl
        hit_sl=price<=p["stop_loss"] if p["side"]=="LONG" else price>=p["stop_loss"]
        hit_tp=price>=p["take_profit"] if p["side"]=="LONG" else price<=p["take_profit"]
        if hit_sl or hit_tp:
            state["balance"]+=pnl; state["realized_pnl"]+=pnl; state["trades"]+=1
            state["history"].insert(0,{"action":"CLOSE","symbol":symbol,"side":p["side"],"price":price,"pnl":pnl,"reason":"STOP_LOSS" if hit_sl else "TAKE_PROFIT","time":now()})
            del state["positions"][symbol]
    state["unrealized_pnl"]=sum(p["unrealized_pnl"] for p in state["positions"].values())
    state["equity"]=state["balance"]+state["unrealized_pnl"]

def execute():
    symbol=random.choice(SYMBOLS)
    votes=[signal(a,symbol) for a in AGENTS if a not in ("Consensus Agent","Risk Guardian")]
    buy=sum(v=="BUY" for v,_ in votes); sell=sum(v=="SELL" for v,_ in votes); hold=len(votes)-buy-sell
    action="BUY" if buy>=5 else "SELL" if sell>=5 else "HOLD"
    state["agents"]=[{"name":a,"signal":signal(a,symbol)[0],"score":signal(a,symbol)[1]} for a in AGENTS]
    state["agents"][-1]={"name":"Consensus Agent","signal":action,"score":round(max(buy,sell)/len(votes)*100)}
    if action not in ("BUY","SELL") or symbol in state["positions"] or state["equity"]<=5: return
    price=state["prices"][symbol]; risk_cash=max(.25,state["equity"]*.01); dist=price*.01
    qty=max(.001,min(state["equity"]*.20/price,risk_cash/dist))
    side="LONG" if action=="BUY" else "SHORT"
    sl,tp=(price*.99,price*1.02) if side=="LONG" else (price*1.01,price*.98)
    state["positions"][symbol]={"symbol":symbol,"side":side,"quantity":qty,"entry_price":price,"stop_loss":sl,"take_profit":tp,"unrealized_pnl":0}
    state["history"].insert(0,{"action":"OPEN","symbol":symbol,"side":side,"price":price,"pnl":0,"votes":{"BUY":buy,"SELL":sell,"HOLD":hold},"time":now()})

def cycle():
    market_step(); update_positions(); execute(); update_positions()
    state["cycle"]+=1; state["last_cycle"]=now(); state["curve"]=(state["curve"]+[state["equity"]])[-80:]

async def loop():
    while True:
        if state["running"]: cycle()
        await asyncio.sleep(5)

@app.on_event("startup")
async def startup(): asyncio.create_task(loop())

@app.get("/api/status")
def status(): return {k:v for k,v in state.items() if k!="prices"} | {"prices":state["prices"],"positions":list(state["positions"].values())}

@app.post("/api/run")
def run(req:RunRequest): state["running"]=req.enabled; return {"running":state["running"]}

@app.post("/api/cycle")
def manual_cycle(): cycle(); return status()

@app.post("/api/reset")
def reset():
    state.update({"running":False,"balance":50.0,"equity":50.0,"realized_pnl":0.0,"unrealized_pnl":0.0,"trades":0,"positions":{},"history":[],"agents":[],"curve":[50.0],"last_cycle":None,"cycle":0})
    return status()
