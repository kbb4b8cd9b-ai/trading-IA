# Trading AI Paper Automatizzato
Mantiene la UI mobile della demo e aggiunge un backend FastAPI con 10 agenti, consenso, Risk Guardian, posizioni, P/L, SL/TP e ciclo automatico ogni 5 secondi. Capitale virtuale iniziale 50 €. Il mercato è un simulatore random-walk: non usa quotazioni reali e non invia ordini a broker.
