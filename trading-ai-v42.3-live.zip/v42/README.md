# Trading AI V4.2 Live

V4.2 is a secure Trading 212 Live API bridge with a mobile dashboard.

## Important
- The package defaults to **read-only live account monitoring**.
- `LIVE_EXECUTION=false` and `KILL_SWITCH=true` are intentional safety defaults.
- Never put API credentials in GitHub Pages or frontend JavaScript.
- Never commit `.env` or API secrets to Git.
- Trading 212 API uses API Key + API Secret via Basic Auth.
- Live orders are only sent when backend execution is explicitly enabled and the kill switch is armed.

## What it currently does
- Reads Trading 212 live account summary.
- Reads real open positions.
- Reads pending orders.
- Reads available instruments.
- Provides a mobile dashboard.
- Has a hard 50 EUR capital ceiling configuration and one-position default.
- Provides an explicit kill switch.

## What is intentionally NOT automatic yet
The package does not fabricate market prices or pretend that random paper signals are suitable for real money. A production-grade live strategy needs a validated real-time market-data source and a tested signal/risk engine before automatic orders are enabled.

## Environment
Copy `.env.example` into the server's secret configuration. Do not paste secrets into chat.

For first validation keep:
`LIVE_EXECUTION=false`
`KILL_SWITCH=true`

Only after account/position reads work should execution be considered, and only after the strategy has been validated on live market data.
