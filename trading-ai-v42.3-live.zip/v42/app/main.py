from __future__ import annotations
import os, time, asyncio
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import httpx
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel

APP_DIR = Path(__file__).resolve().parent.parent
app = FastAPI(title='Trading AI V4.2 Live', version='4.2.0')

T212_BASE = os.getenv('TRADING212_BASE_URL', 'https://live.trading212.com/api/v0').rstrip('/')
API_KEY = os.getenv('TRADING212_API_KEY', '')
API_SECRET = os.getenv('TRADING212_API_SECRET', '')
LIVE_EXECUTION = os.getenv('LIVE_EXECUTION', 'false').lower() == 'true'
KILL_SWITCH = os.getenv('KILL_SWITCH', 'true').lower() == 'true'
MAX_CAPITAL_EUR = float(os.getenv('MAX_CAPITAL_EUR', '50'))
MAX_POSITION_PCT = float(os.getenv('MAX_POSITION_PCT', '0.20'))
MAX_POSITIONS = int(os.getenv('MAX_POSITIONS', '1'))
CYCLE_SECONDS = int(os.getenv('CYCLE_SECONDS', '60'))

AGENTS = ['Trend Hunter','Momentum AI','Mean Reversion','Volatility Scout','Breakout AI','Risk Guardian','Macro Pulse','Pattern Vision','Portfolio Optimizer','Consensus Agent']
WATCHLIST = os.getenv('WATCHLIST', 'AAPL_US_EQ,MSFT_US_EQ,NVDA_US_EQ,TSLA_US_EQ,AMZN_US_EQ').split(',')
state = {'running': False, 'last_cycle': None, 'last_error': None, 'account': None, 'positions': [], 'orders': [], 'agents': [], 'mode': 'LIVE' if LIVE_EXECUTION else 'LIVE-READONLY', 'kill_switch': KILL_SWITCH, 'cycle': 0, 'selected_ticker': None}

class RunRequest(BaseModel): enabled: bool = True
class ArmRequest(BaseModel): confirm: bool
class MarketOrderRequest(BaseModel): ticker: str; quantity: float


def now(): return datetime.now(timezone.utc).isoformat()

def configured(): return bool(API_KEY and API_SECRET)

def auth(): return (API_KEY, API_SECRET)

async def t212(method: str, path: str, **kwargs):
    if not configured():
        raise HTTPException(503, 'Trading 212 API non configurata: imposta TRADING212_API_KEY e TRADING212_API_SECRET sul backend.')
    url = f'{T212_BASE}{path}'
    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.request(method, url, auth=auth(), **kwargs)
    if r.status_code >= 400:
        detail = r.text[:1000]
        raise HTTPException(r.status_code, f'Trading 212 API: {detail}')
    return r.json() if r.content else {}

@app.get('/')
def home(): return FileResponse(APP_DIR / 'index.html')

@app.get('/health')
def health():
    return {'status':'ok','configured':configured(),'mode':state['mode'],'kill_switch':state['kill_switch']}

@app.get('/api/config')
def config():
    return {'configured':configured(),'mode':state['mode'],'live_execution':LIVE_EXECUTION,'kill_switch':state['kill_switch'],'max_capital_eur':MAX_CAPITAL_EUR,'max_position_pct':MAX_POSITION_PCT,'max_positions':MAX_POSITIONS,'cycle_seconds':CYCLE_SECONDS}

@app.get('/api/account')
async def account():
    data = await t212('GET','/equity/account/summary')
    state['account']=data
    return data

@app.get('/api/positions')
async def positions():
    data = await t212('GET','/equity/positions')
    state['positions']=data
    return data

@app.get('/api/orders')
async def orders():
    data = await t212('GET','/equity/orders')
    state['orders']=data
    return data

@app.get('/api/instruments')
async def instruments():
    return await t212('GET','/equity/metadata/instruments')

@app.post('/api/kill')
async def kill():
    state['kill_switch']=True
    state['running']=False
    return {'ok':True,'kill_switch':True}

@app.post('/api/arm')
async def arm(req: ArmRequest):
    if not req.confirm:
        raise HTTPException(400,'Conferma richiesta')
    if not configured(): raise HTTPException(503,'Credenziali API mancanti')
    if not LIVE_EXECUTION: raise HTTPException(409,'LIVE_EXECUTION è disattivato sul backend. Non abilito ordini reali solo dalla UI.')
    state['kill_switch']=False
    return {'ok':True,'kill_switch':False,'message':'Esecuzione live armata. Il Risk Guardian resta obbligatorio.'}

@app.post('/api/run')
def run(req: RunRequest):
    if req.enabled and state['kill_switch']:
        raise HTTPException(409,'Kill switch attivo. Usa /api/arm dopo aver configurato LIVE_EXECUTION=true sul backend.')
    state['running']=req.enabled
    return {'running':state['running']}

@app.post('/api/order/market')
async def market_order(req: MarketOrderRequest):
    if state['kill_switch'] or not LIVE_EXECUTION:
        raise HTTPException(409,'Ordini reali disabilitati: kill switch attivo oppure LIVE_EXECUTION=false.')
    if req.quantity == 0: raise HTTPException(400,'quantity non può essere 0')
    if req.quantity < 0:
        # Selling is allowed by Trading 212 via negative quantity; the caller must have an open position.
        pass
    # Hard cap: do not permit an order whose absolute quantity can exceed MAX_CAPITAL_EUR using the latest position/account data.
    positions = await t212('GET','/equity/positions')
    if len(positions) >= MAX_POSITIONS and req.quantity > 0:
        raise HTTPException(409,'Limite posizioni raggiunto')
    instruments = await t212('GET','/equity/metadata/instruments')
    inst = next((x for x in instruments if x.get('ticker') == req.ticker), None)
    if not inst: raise HTTPException(400,'Ticker non trovato tra gli strumenti Trading 212')
    # Market order body per API: ticker + quantity.
    result = await t212('POST','/equity/orders/market', json={'ticker':req.ticker,'quantity':req.quantity})
    return result

@app.post('/api/cycle')
async def cycle():
    state['cycle'] += 1
    state['last_cycle']=now()
    state['last_error']=None
    try:
        acc = await t212('GET','/equity/account/summary')
        pos = await t212('GET','/equity/positions')
        orders = await t212('GET','/equity/orders')
        state['account']=acc; state['positions']=pos; state['orders']=orders
        state['agents']=[{'name':a,'signal':'READ-ONLY','score':None} for a in AGENTS]
        return {'ok':True,'account':acc,'positions':pos,'orders':orders,'agents':state['agents'],'note':'V4.2 usa dati reali del conto. Nessun ordine viene creato automaticamente in questo ciclo.'}
    except HTTPException as e:
        state['last_error']=e.detail
        raise

@app.get('/api/status')
async def status():
    return state

async def loop():
    while True:
        if state['running']:
            try: await cycle()
            except Exception as e: state['last_error']=str(e)
        await asyncio.sleep(CYCLE_SECONDS)

@app.on_event('startup')
async def startup(): asyncio.create_task(loop())
